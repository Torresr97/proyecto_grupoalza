<?php 
include("../conexion1.php");

var_dump($_POST);
$idequipo=$_POST['mequipo'];


                        if ($idequipo == 'DESKTOP'){
                        $idequipo=$_POST['midequipo'];
                        $empleado=$_POST['mempleado'];
                        $autorizado=$_POST['mautorizado'];
                        $entregado=$_POST['mentregado'];






                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['idempleado'] =  $empleado;
                    $myparams['idequipo'] =  $idequipo;
                    $myparams['autorizado'] = $entregado;
                    $myparams['entregado'] = $autorizado;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['idempleado'], SQLSRV_PARAM_IN),
                    array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['asignador'], SQLSRV_PARAM_IN),
                    array(&$myparams['autorizador'], SQLSRV_PARAM_IN)
                   
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_nuevaasignacion @idempleado = ?, @idequipo = ?,@asignador = ?,@autorizador = ?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    echo'<script type="text/javascript">
                    alert("Datos Ingresados");
                    window.location.href="../../form.php";
                            
                            </script>';


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            
                }
                if ($idequipo == 'LAPTOP'){
                        $idequipo=$_POST['midequipo'];
                        $empleado=$_POST['mempleado'];
                        $autorizado=$_POST['autorizado'];
                        $entregado=$_POST['entregado'];






                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['idempleado'] =  $empleado;
                    $myparams['idequipo'] =  $idequipo;
                    $myparams['autorizado'] = $entregado;
                    $myparams['entregado'] = $autorizado;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['idempleado'], SQLSRV_PARAM_IN),
                    array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['asignador'], SQLSRV_PARAM_IN),
                    array(&$myparams['autorizador'], SQLSRV_PARAM_IN)
                   
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_nuevaasignacion @idempleado = ?, @idequipo = ?,@asignador = ?,@autorizador = ?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    /*echo'<script type="text/javascript">
                    alert("Datos Ingresados");
                    window.location.href="../form.php";
                            
                            </script>';*/


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            
                }

                if ($idequipo == 'CELULAR'){
                        $idequipo=$_POST['mcidequipo'];
                        $empleado=$_POST['mcempleado'];
                        $autorizado=$_POST['autorizado'];
                        $entregado=$_POST['entregado'];






                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['idempleado'] =  $empleado;
                    $myparams['idequipo'] =  $idequipo;
                    $myparams['autorizado'] = $entregado;
                    $myparams['entregado'] = $autorizado;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['idempleado'], SQLSRV_PARAM_IN),
                    array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['asignador'], SQLSRV_PARAM_IN),
                    array(&$myparams['autorizador'], SQLSRV_PARAM_IN)
                   
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_nuevaasignacion @idempleado = ?, @idequipo = ?,@asignador = ?,@autorizador = ?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    /*echo'<script type="text/javascript">
                    alert("Datos Ingresados");
                    window.location.href="../form.php";
                            
                            </script>';*/


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            
                }






?>
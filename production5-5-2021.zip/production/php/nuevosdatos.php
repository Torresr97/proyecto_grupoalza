<?php

include("conexion1.php");

 
 
var_dump($_POST);
    $nomreequpo=$_POST['tipoequipo'];
    if($nomreequpo == 'DESKTOP'){
        $ciudad=$_POST['ciudad'];
        $marca=$_POST['dmarca'];
        $modelo=$_POST['dmodelo'];
        $servicet=$_POST['dservicetag'];
        $ram=$_POST['dram'];
        $procesador=$_POST['dprocesador'];
        $discoduro=$_POST['ddiscoduro'];
        $descrip=$_POST['ddescripcion'];
    
                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['ciudad'] =  $ciudad;
                    $myparams['nombreequipo'] =  $nomreequpo;
                    $myparams['marca_desktop'] = $marca;
                    $myparams['modelo_desktop'] = $modelo;
                    $myparams['servicetag_desktop'] = $servicet;
                    $myparams['ram_desktop'] = $ram;
                    $myparams['procesador_desktop'] = $procesador;
                    $myparams['discoduro_desktop'] = $discoduro;
                    $myparams['descripcion_desktop'] = $descrip;
                    $myparams['marca_laptop'] = null;
                    $myparams['modelo_laptop'] = null;
                    $myparams['servicetag_laptop'] = null;
                    $myparams['procesador_laptop'] = null;
                    $myparams['ram_laptop'] = null;
                    $myparams['discoduro_laptop'] = null;
                    $myparams['descripcion_laptop'] = null;
                    $myparams['marca_cel'] = null;
                    $myparams['modelo_cel'] = null;
                    $myparams['imei_cel'] = null;
                    $myparams['descripcion_cel'] = null;
                    $myparams['marca_tel'] = null;
                    $myparams['modelo_tel'] = null;
                    $myparams['imei_tel'] = null;
                    $myparams['descripcion_tel'] = null;
                    $myparams['nombre_otro'] = null;
                    $myparams['marca_otro'] = null;
                    $myparams['modelo_otro'] = null;
                    $myparams['descripcion_otro'] = null;



                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                    array(&$myparams['nombreequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                    array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                    array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                    array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                    array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                    array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                    array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                    array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                    array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                    array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                    array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                    array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                    array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                    array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_insertardatosdesktop @ciudad = ?, @nombreequipo = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                    
                    echo'<script type="text/javascript">
                        window.location.href="../form.php";
                            alert("Datos Ingresados");
                            </script>';
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            




        
            }//fin  del if desktop



            if($nomreequpo == 'LAPTOP'){
                $ciudad=$_POST['ciudad'];
                $marca=$_POST['lmarca'];
                $modelo=$_POST['lmodelo'];
                $servicet=$_POST['lservicetag'];
                $ram=$_POST['lram'];
                $procesador=$_POST['lprocesador'];
                $discoduro=$_POST['ldiscoduro'];
                $descrip=$_POST['ldescripcion'];
            
                                    // specify params - MUST be a variable that can be passed by reference!
                            $myparams['ciudad'] =  $ciudad;
                            $myparams['nombreequipo'] =  $nomreequpo;
                            $myparams['marca_desktop'] = null;
                            $myparams['modelo_desktop'] = null;
                            $myparams['servicetag_desktop'] = null;
                            $myparams['ram_desktop'] = null;
                            $myparams['procesador_desktop'] = null;
                            $myparams['discoduro_desktop'] = null;
                            $myparams['descripcion_desktop'] = null;
                            $myparams['marca_laptop'] = $marca;
                            $myparams['modelo_laptop'] = $modelo;
                            $myparams['servicetag_laptop'] = $servicet;
                            $myparams['procesador_laptop'] = $procesador;
                            $myparams['ram_laptop'] = $ram;
                            $myparams['discoduro_laptop'] = $discoduro;
                            $myparams['descripcion_laptop'] = $descrip;
                            $myparams['marca_cel'] = null;
                            $myparams['modelo_cel'] = null;
                            $myparams['imei_cel'] = null;
                            $myparams['descripcion_cel'] = null;
                            $myparams['marca_tel'] = null;
                            $myparams['modelo_tel'] = null;
                            $myparams['imei_tel'] = null;
                            $myparams['descripcion_tel'] = null;
                            $myparams['nombre_otro'] = null;
                            $myparams['marca_otro'] = null;
                            $myparams['modelo_otro'] = null;
                            $myparams['descripcion_otro'] = null;
        
        
        
                           // $myparams['marca_laptop'] = null;
        
                            // Set up the proc params array - be sure to pass the param by reference
                            $procedure_params = array(
                            array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                            array(&$myparams['nombreequipo'], SQLSRV_PARAM_IN),
                            array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                            array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                            array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                            array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                            array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                            array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                            array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                            array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                            array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                            array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                            array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                            array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                            array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                            array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                            );
        
                            // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                            $sql = "EXEC Proc_insertardatosdesktop @ciudad = ?, @nombreequipo = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";
        
                            $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);
        
                            if( !$stmt ) {
                            die( print_r( sqlsrv_errors(), true));
                            }
        
                            if(sqlsrv_execute($stmt)){
                            while($res = sqlsrv_next_result($stmt)){
                                // make sure all result sets are stepped through, since the output params may not be set until this happens
                            }
                            // Output params are now set,
                            
                            echo'<script type="text/javascript">
                                window.location.href="../form.php";
                                    alert("Datos Ingresados");
                                    </script>';
                            }else{
                            die( print_r( sqlsrv_errors(), true));
                            }      
                                    
        
        
        
        
                
                    }//fin  del if laptop


                    if($nomreequpo == 'CELULAR'){
                        $ciudad=$_POST['ciudad'];
                        $marca=$_POST['cmarca'];
                        $modelo=$_POST['cmodelo'];
                        $imei=$_POST['cimei'];
                        $descrip=$_POST['cdescripcion'];
                        
                    
                                            // specify params - MUST be a variable that can be passed by reference!
                                    $myparams['ciudad'] =  $ciudad;
                                    $myparams['nombreequipo'] =  $nomreequpo;
                                    $myparams['marca_desktop'] = null;
                                    $myparams['modelo_desktop'] = null;
                                    $myparams['servicetag_desktop'] = null;
                                    $myparams['ram_desktop'] = null;
                                    $myparams['procesador_desktop'] = null;
                                    $myparams['discoduro_desktop'] = null;
                                    $myparams['descripcion_desktop'] = null;
                                    $myparams['marca_laptop'] = null;
                                    $myparams['modelo_laptop'] = null;
                                    $myparams['servicetag_laptop'] = null;
                                    $myparams['procesador_laptop'] = null;
                                    $myparams['ram_laptop'] = null;
                                    $myparams['discoduro_laptop'] = null;
                                    $myparams['descripcion_laptop'] = null;
                                    $myparams['marca_cel'] = $marca;
                                    $myparams['modelo_cel'] = $modelo;
                                    $myparams['imei_cel'] = $imei;
                                    $myparams['descripcion_cel'] = $descrip;
                                    $myparams['marca_tel'] = null;
                                    $myparams['modelo_tel'] = null;
                                    $myparams['imei_tel'] = null;
                                    $myparams['descripcion_tel'] = null;
                                    $myparams['nombre_otro'] = null;
                                    $myparams['marca_otro'] = null;
                                    $myparams['modelo_otro'] = null;
                                    $myparams['descripcion_otro'] = null;
                
                
                
                                   // $myparams['marca_laptop'] = null;
                
                                    // Set up the proc params array - be sure to pass the param by reference
                                    $procedure_params = array(
                                    array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                                    array(&$myparams['nombreequipo'], SQLSRV_PARAM_IN),
                                    array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                                    array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                                    array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                                    array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                                    array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                                    array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                                    );
                
                                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                                    $sql = "EXEC Proc_insertardatosdesktop @ciudad = ?, @nombreequipo = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";
                
                                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);
                
                                    if( !$stmt ) {
                                    die( print_r( sqlsrv_errors(), true));
                                    }
                
                                    if(sqlsrv_execute($stmt)){
                                    while($res = sqlsrv_next_result($stmt)){
                                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                                    }
                                    // Output params are now set,
                                    
                                    echo'<script type="text/javascript">
                                        window.location.href="../form.php";
                                            alert("Datos Ingresados");
                                            </script>';
                                    }else{
                                    die( print_r( sqlsrv_errors(), true));
                                    }      
                                            
                
                
                
                
                        
                            }//fin  del if celular


                            if($nomreequpo == 'TELEFONO'){
                                $ciudad=$_POST['ciudad'];
                                $marca=$_POST['tmarca'];
                                $modelo=$_POST['tmodelo'];
                                $imei=$_POST['timei'];
                                $descrip=$_POST['tdescripcion'];
                                
                            
                                                    // specify params - MUST be a variable that can be passed by reference!
                                            $myparams['ciudad'] =  $ciudad;
                                            $myparams['nombreequipo'] =  $nomreequpo;
                                            $myparams['marca_desktop'] = null;
                                            $myparams['modelo_desktop'] = null;
                                            $myparams['servicetag_desktop'] = null;
                                            $myparams['ram_desktop'] = null;
                                            $myparams['procesador_desktop'] = null;
                                            $myparams['discoduro_desktop'] = null;
                                            $myparams['descripcion_desktop'] = null;
                                            $myparams['marca_laptop'] = null;
                                            $myparams['modelo_laptop'] = null;
                                            $myparams['servicetag_laptop'] = null;
                                            $myparams['procesador_laptop'] = null;
                                            $myparams['ram_laptop'] = null;
                                            $myparams['discoduro_laptop'] = null;
                                            $myparams['descripcion_laptop'] = null;
                                            $myparams['marca_cel'] = null;
                                            $myparams['modelo_cel'] = null;
                                            $myparams['imei_cel'] = null;
                                            $myparams['descripcion_cel'] = null;
                                            $myparams['marca_tel'] = $marca;
                                            $myparams['modelo_tel'] = $modelo;
                                            $myparams['imei_tel'] = $imei;
                                            $myparams['descripcion_tel'] = $descrip;
                                            $myparams['nombre_otro'] = null;
                                            $myparams['marca_otro'] = null;
                                            $myparams['modelo_otro'] = null;
                                            $myparams['descripcion_otro'] = null;
                        
                        
                        
                                           // $myparams['marca_laptop'] = null;
                        
                                            // Set up the proc params array - be sure to pass the param by reference
                                            $procedure_params = array(
                                            array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                                            array(&$myparams['nombreequipo'], SQLSRV_PARAM_IN),
                                            array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                                            array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                                            array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                                            array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                                            array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                                            array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                                            );
                        
                                            // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                                            $sql = "EXEC Proc_insertardatosdesktop @ciudad = ?, @nombreequipo = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";
                        
                                            $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);
                        
                                            if( !$stmt ) {
                                            die( print_r( sqlsrv_errors(), true));
                                            }
                        
                                            if(sqlsrv_execute($stmt)){
                                            while($res = sqlsrv_next_result($stmt)){
                                                // make sure all result sets are stepped through, since the output params may not be set until this happens
                                            }
                                            // Output params are now set,
                                            
                                            echo'<script type="text/javascript">
                                                window.location.href="../form.php";
                                                    alert("Datos Ingresados");
                                                    </script>';
                                            }else{
                                            die( print_r( sqlsrv_errors(), true));
                                            }      
                                                    
                        
                        
                        
                        
                                
                                    }//fin  del if telefono


                                    if($nomreequpo == 'OTROS'){
                                        $ciudad=$_POST['ciudad'];
                                        $nombre=$_POST['onombre'];
                                        $marca=$_POST['omodelo'];
                                        $modelo=$_POST['omodelo'];
                                        $descrip=$_POST['odescripcion'];
                                        
                                    
                                                            // specify params - MUST be a variable that can be passed by reference!
                                                    $myparams['ciudad'] =  $ciudad;
                                                    $myparams['nombreequipo'] =  $nomreequpo;
                                                    $myparams['marca_desktop'] = null;
                                                    $myparams['modelo_desktop'] = null;
                                                    $myparams['servicetag_desktop'] = null;
                                                    $myparams['ram_desktop'] = null;
                                                    $myparams['procesador_desktop'] = null;
                                                    $myparams['discoduro_desktop'] = null;
                                                    $myparams['descripcion_desktop'] = null;
                                                    $myparams['marca_laptop'] = null;
                                                    $myparams['modelo_laptop'] = null;
                                                    $myparams['servicetag_laptop'] = null;
                                                    $myparams['procesador_laptop'] = null;
                                                    $myparams['ram_laptop'] = null;
                                                    $myparams['discoduro_laptop'] = null;
                                                    $myparams['descripcion_laptop'] = null;
                                                    $myparams['marca_cel'] = null;
                                                    $myparams['modelo_cel'] = null;
                                                    $myparams['imei_cel'] = null;
                                                    $myparams['descripcion_cel'] = null;
                                                    $myparams['marca_tel'] = null;
                                                    $myparams['modelo_tel'] = null;
                                                    $myparams['imei_tel'] = null;
                                                    $myparams['descripcion_tel'] = null;
                                                    $myparams['nombre_otro'] = $nombre;
                                                    $myparams['marca_otro'] = $marca;
                                                    $myparams['modelo_otro'] = $modelo;
                                                    $myparams['descripcion_otro'] = $descrip;
                                
                                
                                
                                                   // $myparams['marca_laptop'] = null;
                                
                                                    // Set up the proc params array - be sure to pass the param by reference
                                                    $procedure_params = array(
                                                    array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['nombreequipo'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                                                    array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                                                    );
                                
                                                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                                                    $sql = "EXEC Proc_insertardatosdesktop @ciudad = ?, @nombreequipo = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";
                                
                                                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);
                                
                                                    if( !$stmt ) {
                                                    die( print_r( sqlsrv_errors(), true));
                                                    }
                                
                                                    if(sqlsrv_execute($stmt)){
                                                    while($res = sqlsrv_next_result($stmt)){
                                                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                                                    }
                                                    // Output params are now set,
                                                    
                                                   /* echo'<script type="text/javascript">
                                                        window.location.href="../form.php";
                                                            alert("Datos Ingresados");
                                                            </script>';*/
                                                    }else{
                                                    die( print_r( sqlsrv_errors(), true));
                                                    }      
                                                            
                                
                                
                                
                                
                                        
                                            }//fin  del if laptop

   
?>


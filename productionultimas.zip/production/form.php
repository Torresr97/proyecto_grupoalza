
<!DOCTYPE html>
<html lang="en">
  <head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Gentelella Alela! | </title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
	
	<!-- Bootstrap -->
	
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- bootstrap-wysiwyg -->
	<link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
	<!-- Select2 -->
	<link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
	<!-- Switchery -->
	<link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
	<!-- starrr -->
	<link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
	<!-- bootstrap-daterangepicker -->
	<link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

	<!-- Custom Theme Style -->
	<link href="../build/css/custom.min.css" rel="stylesheet">

</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>Grupo Alza</span></a>
					</div>

					<div class="clearfix"></div>

				

					<br />

					 <!-- sidebar menu -->
					 <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Inventarios</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Grupo Alza <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.php">Registro</a></li>
                      <li><a href="asignacion.php">Asignacion</a></li>
                      <li><a href="recepcion.php">Recepcion</a></li>
                      <li><a href="inventario.php">Inventario</a></li>
                    </ul>
                  </li>
                 
               
                 
              </div>
             
            </div>
            <!-- /sidebar menu -->

					<!-- /menu footer buttons -->
					<div class="sidebar-footer hidden-small">
						<a data-toggle="tooltip" data-placement="top" title="Settings">
							<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="FullScreen">
							<span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="Lock">
							<span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
							<span class="glyphicon glyphicon-off" aria-hidden="true"></span>
						</a>
					</div>
					<!-- /menu footer buttons -->
				</div>
			</div>

			<!-- top navigation -->
			<div class="top_nav">
				<div class="nav_menu">
					<div class="nav toggle">
						<a id="menu_toggle"><i class="fa fa-bars"></i></a>
					</div>
					<nav class="nav navbar-nav">
						<ul class=" navbar-right">
							<li class="nav-item dropdown open" style="padding-left: 15px;">
								<a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
									<img src="images/img.jpg" alt="">John Doe
								</a>
								<div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
									<a class="dropdown-item" href="javascript:;"> Profile</a>
									<a class="dropdown-item" href="javascript:;">
										<span class="badge bg-red pull-right">50%</span>
										<span>Settings</span>
									</a>
									<a class="dropdown-item" href="javascript:;">Help</a>
									<a class="dropdown-item" href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
								</div>
							</li>

							<li role="presentation" class="nav-item dropdown open">
								<a href="javascript:;" class="dropdown-toggle info-number" id="navbarDropdown1" data-toggle="dropdown" aria-expanded="false">
									<i class="fa fa-envelope-o"></i>
									
								</a>
								<ul class="dropdown-menu list-unstyled msg_list" role="menu" aria-labelledby="navbarDropdown1">
								
								</ul>
							</li>
						</ul>
					</nav>
				</div>
			</div>
			<!-- /top navigation -->

			<!-- page content -->
			<div  class="right_col" role="main">

				<div class="col-md-12 ">
					<div class="x_panel">
						<div class="x_title">
								<h2>Registro Equipo </h2>
								<ul class="nav navbar-right panel_toolbox">
								
								</ul>
							<div class="clearfix"></div>
						</div>

						<div class="x_content">
							<br />
				<form id="fmrselecttemporal">
				<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="CELULAR">Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada" selected>Seleccione un Equipo</option>
									<option value="desktop" >Desktop</option>
									<option value="laptop">Laptop</option>
									<option value="celular">Celular</option>
									<option value="telefono">Telefono</option>
									<option value="otros">Otros</option>
								
								</select>
							</div>
						</div>
				
				</form>
					

	<!--FORMULARIO PARA laptop-->		
					<div id="fmrlaptop" style="display: none;">
						<form  method="POST"  action="php\nuevosdatos.php"  class="form-horizontal form-label-left">
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="PROYESA">Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada">Seleccione un Equipo</option>
									<option value="DESKTOP" >Desktop</option>
									<option value="LAPTOP" selected>Laptop</option>
									<option value="CELULAR">Celular</option>
									<option value="TELEFONO">Telefono</option>
									<option value="OTROS">Otros</option>
								
								</select>
							</div>
						</div>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">Marca</label>
											<div class="col-md-5 col-sm-5 ">
												<input id="lmarca" name="lmarca"  type="text"  class="form-control" placeholder="Marca LAPTOP">
											</div>
										</div>

										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
											<div class="col-md-5 col-sm-5 ">
												<input id="lmodelo" name="lmodelo" type="text" class="form-control" placeholder="Modelo">
											</div>
										</div>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">Service Tag</label>
											<div class="col-md-5 col-sm-5 ">
												<input id="lservicetag" name="lservicetag" type="text" class="form-control" placeholder="Service Tag">
											</div>
										</div>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">Procesador</label>
											<div class="col-md-5 col-sm-5 ">
												<input id="lprocesador" name="lprocesador" type="text" class="form-control" placeholder="Procesador">
											</div>
										</div>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">RAM</label>
											<div class="col-md-5 col-sm-5 ">
												<input  id="lram" name="lram" type="number" class="form-control" placeholder="Ram">
											</div>
										</div>
										<div class="form-group row ">
											<label class="control-label col-md-3 col-sm-3 ">Disco Duro</label>
											<div class="col-md-5 col-sm-5 ">
												<input id="ldiscoduro" name="ldiscoduro" type="number" class="form-control" placeholder="Disco Duro">
											</div>
										</div>
										<div class="form-group row">
											<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
											</label>
											<div class="col-md-9 col-sm-9 ">
												<textarea id="ldescripcion" name="ldescripcion" class="form-control" rows="3" placeholder="Descripcion"></textarea>
											</div>
										</div>
										<div class="ln_solid"></div>
										<div  id="btnlaptop"  class="item form-group">
												<div  class="col-md-6 col-sm-6 offset-md-3">
													
													<button class="btn btn-primary" type="reset">Reset</button>
													<button type="submit" class="btn btn-success">Submit</button>
												</div>
											</div>
										
								
								</form>
					</div>

	<!--FORMULARIO PARA laptop-->	



	
	<!--FORMULARIO PARA desktop-->	
	<div id="fmrdesktop" style="display: none;">
	<form id="fmrdesktop" method="POST"  action="php\nuevosdatos.php"  class="form-horizontal form-label-left">
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="PROYESA">Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada">Seleccione un Equipo</option>
									<option value="DESKTOP" selected>Desktop</option>
									<option value="LAPTOP">Laptop</option>
									<option value="CELULAR">Celular</option>
									<option value="TELEFONO">Telefono</option>
									<option value="OTROS">Otros</option>
								
								</select>
							</div>
						</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Marca</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dmarca" name="dmarca"  type="text"  class="form-control" placeholder="Marca DESKTOP" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dmodelo" name="dmodelo" type="text" class="form-control" placeholder="Modelo" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Service Tag</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dservicetag" name="dservicetag" type="text" class="form-control" placeholder="Service Tag" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Procesador</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dprocesador" name="dprocesador" type="text" class="form-control" placeholder="Procesador" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">RAM</label>
						<div class="col-md-5 col-sm-5 ">
							<input  id="dram" name="dram" type="number" class="form-control" placeholder="Ram" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Disco Duro</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="ddiscoduro" name="ddiscoduro" type="number" class="form-control" placeholder="Disco Duro"required="required">
						</div>
					</div>
					<div class="form-group row">
						<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
						</label>
						<div class="col-md-9 col-sm-9 ">
							<textarea id="ddescripcion" name="ddescripcion"  class="form-control" rows="3" placeholder="Descripcion"></textarea>
						</div>
					</div>
					<div class="ln_solid"></div>
					<div  id="btndesktop"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button   id="btnenviardesktop"   class="btn btn-success" >Submit</button>
											</div>
										</div>
				
			
			</form>
	</div>
	<!--FORMULARIO PARA desktop-->	


<!--FORMULARIO PARA CELULAR-->	
<div id="fmrcelular" style="display: none;">
<form id="fmrcelular"  method="POST"  action="php\nuevosdatos.php"  class="form-horizontal form-label-left">
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="PROYESA" >Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada">Seleccione un Equipo</option>
									<option value="DESKTOP" >Desktop</option>
									<option value="LAPTOP">Laptop</option>
									<option value="CELULAR" selected>Celular</option>
									<option value="TELEFONO">Telefono</option>
									<option value="OTROS">Otros</option>
								
								</select>
							</div>
						</div>
						<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Marca</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cmarca" name="cmarca" type="text" class="form-control" placeholder="Marca">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cmodelo" name="cmodelo" type="text" class="form-control" placeholder="Modelo">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">IMEI</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cimei" name="cimei" type="text" class="form-control" placeholder="Imei">
										</div>
									</div>
								
									<div class="form-group row">
										<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
										</label>
										<div class="col-md-9 col-sm-9 ">
											<textarea id="cdescripcion" name="cdescripcion"  class="form-control" rows="3" placeholder="Descripcion"></textarea>
										</div>
									</div>
									<div class="ln_solid"></div>
									<div    class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button class="btn btn-success">Submit</button>
											</div>
										</div>
						
							
							</form>


</div>
<!--FORMULARIO PARA CELULAR-->	



<!--FORMULARIO PARA telefono-->	
<div id="fmrtelefono" style="display: none;">
		<form id="fmrtelefono"  method="POST"  action="php\nuevosdatos.php" class="form-horizontal form-label-left">
		<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="PROYESA">Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada">Seleccione un Equipo</option>
									<option value="DESKTOP" >Desktop</option>
									<option value="LAPTOP">Laptop</option>
									<option value="CELULAR">Celular</option>
									<option value="TELEFONO" selected>Telefono</option>
									<option value="OTROS">Otros</option>
								
								</select>
							</div>
						</div>
						<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Marca</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="tmarca" name="tmarca" type="number" class="form-control" placeholder="Marca">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="tmodelo" name="tmodelo" type="number" class="form-control" placeholder="Modelo">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">IMEI</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="timei" name="timei" type="number" class="form-control" placeholder="Imei">
										</div>
									</div>
								
									<div class="form-group row">
										<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
										</label>
										<div class="col-md-9 col-sm-9 ">
											<textarea id="tdescripcion" name="tdescripcion"  class="form-control" rows="3" placeholder="Descripcion"></textarea>
										</div>
									</div>
									<div class="ln_solid"></div>
									<div  id="btncelular"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button type="submit" class="btn btn-success">Submit</button>
											</div>
										</div>
							
							
							</form>


</div>
<!--FORMULARIO PARA telefono-->	


<!--FORMULARIO PARA otros-->	
<div id="fmrotro" style="display: none;">
<form  method="POST"  action="php\nuevosdatos.php"   class="form-horizontal form-label-left">
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control"  name="ciudad" id="ciudad" >
									<option value="nulo" >Seleccione un Centro de Distribucion</option>
										<option value="SPS" >SPS</option>
										<option value="TGU">TGU</option>
										<option value="CELULAR">Proyesa</option>
										<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
										<option value="GRALZA">Gralza</option>
									
								</select>
							</div>
						</div>


				
						<div class="form-group row">
							<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
							<div class="col-md-4 col-sm-4 ">
								<select  class="form-control" name="tipoequipo" id="tipoequipo"  onChange="mostrar(this.value)" >
									<option value="nada">Seleccione un Equipo</option>
									<option value="DESKTOP" >Desktop</option>
									<option value="LAPTOP">Laptop</option>
									<option value="CELULAR">Celular</option>
									<option value="TELEFONO">Telefono</option>
									<option value="OTROS" selected>Otros</option>
								
								</select>
							</div>
						</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Nombre del Equipo</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="onombre" name="onombre" type="text" class="form-control" placeholder="Nombre del Equipo">
									</div>
								</div>
								
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Marca</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="omarca" name="omarca" type="text" class="form-control" placeholder="Marca">
									</div>
								</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="omodelo" name="omodelo" type="text" class="form-control" placeholder="Modelo">
									</div>
								</div>
								
								<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
									</label>
									<div class="col-md-9 col-sm-9 ">
										<textarea id="odescripcion" name="odescripcion" class="form-control" rows="3" placeholder="Descripcion"></textarea>
									</div>
								</div>
								
							<div  id="btnotros"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button   class="btn btn-success" >Submit</button>
											</div>
										</div>
										
								
							
								</form>

</div>

<!--FORMULARIO PARA otros-->




				</div>
	</div>

<script type="text/javascript">
			
$(document).ready(function(){
	mostrar();
	$('#tipoequipo').val("nada").click(); 
});		



/*$("#btnenviardesktop" ).click(function() {

	$('#btnenviarselect').submit();
});*/
				




function mostrar(id) {
    if (id == "nada") {
		$("#fmrdesktop").hide();
		$("#fmrlaptop").hide();
		$("#fmrcelular").hide();
		$("#fmrtelefono").hide();
		$("#fmrotro").hide();
		$("#fmrselecttemporal").show();
		
    }

    if (id == "desktop") {
		$("#fmrdesktop").show();
		$("#fmrlaptop").hide();
		$("#fmrcelular").hide();
		$("#fmrtelefono").hide();
		$("#fmrotro").hide();
		$("#fmrselecttemporal").hide();
		
		alert("es desktop");
    }

    if (id == "laptop") {
		$("#fmrlaptop").show();
		$("#fmrdesktop").hide();
		$("#fmrcelular").hide();
		$("#fmrtelefono").hide();
		$("#fmrotro").hide();
		$("#fmrselecttemporal").hide();
        alert("es laptop");
    }

    if (id == "celular") {
		$("#fmrlaptop").hide();
		$("#fmrdesktop").hide();
		$("#fmrcelular").show();
		$("#fmrtelefono").hide();
		$("#fmrotro").hide();
		$("#fmrselecttemporal").hide();
        alert("es celular");
    }
	if (id == "telefono") {
		$("#fmrlaptop").hide();
		$("#fmrdesktop").hide();
		$("#fmrcelular").hide();
		$("#fmrtelefono").show();
		$("#fmrotro").hide();
		$("#fmrselecttemporal").hide();
        alert("es telefonos");
    }
	if (id == "otros") {
		$("#fmrlaptop").hide();
		$("#fmrdesktop").hide();
		$("#fmrcelular").hide();
		$("#fmrtelefono").hide();
		$("#fmrotro").show();
		$("#fmrselecttemporal").hide();
        alert("es otros");
    }
}		
			

</script>
	
	


	<!-- jQuery -->
	<script src="../vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<!-- FastClick -->
	<script src="../vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="../vendors/nprogress/nprogress.js"></script>
	<!-- bootstrap-progressbar -->
	<script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	<!-- iCheck -->
	<script src="../vendors/iCheck/icheck.min.js"></script>
	<!-- bootstrap-daterangepicker -->
	<script src="../vendors/moment/min/moment.min.js"></script>
	<script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	<!-- bootstrap-wysiwyg -->
	<script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
	<script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
	<script src="../vendors/google-code-prettify/src/prettify.js"></script>
	<!-- jQuery Tags Input -->
	<script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
	<!-- Switchery -->
	<script src="../vendors/switchery/dist/switchery.min.js"></script>
	<!-- Select2 -->
	<script src="../vendors/select2/dist/js/select2.full.min.js"></script>
	<!-- Parsley -->
	<script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
	<!-- Autosize -->
	<script src="../vendors/autosize/dist/autosize.min.js"></script>
	<!-- jQuery autocomplete -->
	<script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
	<!-- starrr -->
	<script src="../vendors/starrr/dist/starrr.js"></script>
	<!-- Custom Theme Scripts -->
	<script src="../build/js/custom.min.js"></script>

</body></html>
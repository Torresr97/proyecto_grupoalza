<?php
include("php\conexion1.php");
?>
<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Empleado:</label>
									<div class="col-md-4 col-sm-4 ">
								
									<select  class="form-control"  name="mempleado" id="mempleado" >
									<?php
											$sql = "SELECT idempleado,NombreCompleto FROM dbo.inventario_empleado order by NombreCompleto";
											$stmt = sqlsrv_query( $conn, $sql );
											if( $stmt === false) {
												die( print_r( sqlsrv_errors(), true) );
											}
											

											while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
												
												echo '<option value="' .$row['idempleado']. '">' .$row['NombreCompleto']. '</option>';
											
												
												
											} 
											sqlsrv_close( $conn ) ; 
											?>
											
											</select>
											
											</div>
											</div>
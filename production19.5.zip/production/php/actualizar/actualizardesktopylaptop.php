<?php 
include("../conexion1.php");

var_dump($_POST);


$equipo=$_POST['mequipo'];


                        if ($equipo == 'DESKTOP'){
                        $idequipo=$_POST['midequipo'];
                        $marca=$_POST['mmarca'];
                        $modelo=$_POST['mmodelo'];
                        $servicetag=$_POST['mservicetag'];
                        $procesador=$_POST['mprocesador'];
                        $ram=$_POST['mram'];
                        $discoduro=$_POST['mdiscoduro'];
                        $descripcion=$_POST['mdescripcion'];
                        $ciudad=$_POST['ciudad'];
                       






                            // specify params - MUST be a variable that can be passed by reference!
                            $myparams['idequipo'] =  $idequipo;
                            $myparams['ciudad'] =  $ciudad;
                            $myparams['marca_desktop'] = $marca;
                            $myparams['modelo_desktop'] = $modelo;
                            $myparams['servicetag_desktop'] = $servicetag;
                            $myparams['ram_desktop'] = $ram;
                            $myparams['procesador_desktop'] = $procesador;
                            $myparams['discoduro_desktop'] = $discoduro;
                            $myparams['descripcion_desktop'] = $descripcion;
                            $myparams['marca_laptop'] = null;
                            $myparams['modelo_laptop'] = null;
                            $myparams['servicetag_laptop'] = null;
                            $myparams['procesador_laptop'] = null;
                            $myparams['ram_laptop'] = null;
                            $myparams['discoduro_laptop'] = null;
                            $myparams['descripcion_laptop'] = null;
                            $myparams['marca_cel'] = null;
                            $myparams['modelo_cel'] = null;
                            $myparams['imei_cel'] = null;
                            $myparams['descripcion_cel'] = null;
                            $myparams['marca_tel'] = null;
                            $myparams['modelo_tel'] = null;
                            $myparams['imei_tel'] = null;
                            $myparams['descripcion_tel'] = null;
                            $myparams['nombre_otro'] = null;
                            $myparams['marca_otro'] = null;
                            $myparams['modelo_otro'] = null;
                            $myparams['descripcion_otro'] = null;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                        array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                        array(&$myparams['ciudad'], SQLSRV_PARAM_IN),
                        array(&$myparams['marca_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['modelo_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['servicetag_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['ram_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['procesador_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['discoduro_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['descripcion_desktop'], SQLSRV_PARAM_IN),
                        array(&$myparams['marca_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['modelo_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['servicetag_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['procesador_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['ram_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['discoduro_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['descripcion_laptop'], SQLSRV_PARAM_IN),
                        array(&$myparams['marca_cel'], SQLSRV_PARAM_IN),
                        array(&$myparams['modelo_cel'], SQLSRV_PARAM_IN),
                        array(&$myparams['imei_cel'], SQLSRV_PARAM_IN),
                        array(&$myparams['descripcion_cel'], SQLSRV_PARAM_IN),
                        array(&$myparams['marca_tel'], SQLSRV_PARAM_IN),
                        array(&$myparams['modelo_tel'], SQLSRV_PARAM_IN),
                        array(&$myparams['imei_tel'], SQLSRV_PARAM_IN),
                        array(&$myparams['descripcion_tel'], SQLSRV_PARAM_IN),
                        array(&$myparams['nombre_otro'], SQLSRV_PARAM_IN),
                        array(&$myparams['marca_otro'], SQLSRV_PARAM_IN),
                        array(&$myparams['modelo_otro'], SQLSRV_PARAM_IN),
                        array(&$myparams['descripcion_otro'], SQLSRV_PARAM_IN)
                        );

                     // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                     $sql = "EXEC proc_actualizar  @idequipo = ?, @ciudad = ?,@marca_desktop = ?,@modelo_desktop = ?,@servicetag_desktop = ?,@ram_desktop = ?,@procesador_desktop = ?,@discoduro_desktop = ?,@descripcion_desktop = ?,@marca_laptop=?,@modelo_laptop = ?,@servicetag_laptop = ?, @ram_laptop=?,@procesador_laptop=?,@discoduro_laptop=?,@descripcion_laptop=?,@marca_cel=?,@modelo_cel=?,@imei_cel=?,@descripcion_cel=?,@marca_tel=?,@modelo_tel=?,@imei_tel=?,@descripcion_tel=?,@nombre_otro=?,@marca_otro=?,@modelo_otro=?,@descripcion_otro=?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    echo'<script type="text/javascript">
                    alert("Datos Ingresados");
                    window.location.href="../../form.php";
                            
                            </script>';


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            
                }
                if ($equipo == 'LAPTOP'){
                        $idequipo=$_POST['midequipo'];
                        $empleado=$_POST['mempleado'];
                        $autorizado=$_POST['mautorizado'];
                        $entregado=$_POST['mentregado'];






                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['idempleado'] =  $empleado;
                    $myparams['idequipo'] =  $idequipo;
                    $myparams['asignador'] = $entregado;
                    $myparams['autorizador'] = $autorizado;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['idempleado'], SQLSRV_PARAM_IN),
                    array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['asignador'], SQLSRV_PARAM_IN),
                    array(&$myparams['autorizador'], SQLSRV_PARAM_IN)
                   
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_nuevaasignacion @idempleado = ?, @idequipo = ?,@asignador = ?,@autorizador = ?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    echo'<script type="text/javascript">
                    alert("Datos Ingresados");
                    window.location.href="../../form.php";
                            
                            </script>';


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            
                }


?>
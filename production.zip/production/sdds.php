/*$(function() {
  $("#btnenviardesktop").click(function(event) {
    //Evita que se recargue la página
    event.preventDefault();
    // Serializamos en una sola variable ambos formularios
	var allData = $('#fmrdesktop, #frmselect').serialize()
  
    //Prueba
    alert(allData);
    //Podemos usar allData para enviarlo por Ajax o lo que sea
	$.ajax({
	type: 'POST',
	url: 'php/nuevosdatos.php',
	data: $('#fmrdesktop, #frmselect').serialize(),
	dataType: "json",
	success: function() {
		alert("datos enviados");
	}
	});
  });
});
*/
$("#btnenviardesktop").click(function(event) {
	document.frmselect.submit();
}
	


$("#btnenviardatosdatatable").click(function(event) {
		/*Evita que se recargue la página*/
		event.preventDefault();
		/* Serializamos en una sola variable ambos formularios*/
		var personaasignada = document.getElementById("personaasignada").value;
		var autorizado = document.getElementById("autorizado").value;
		var entregado = document.getElementById("entregado").value;
		


		var dataString = 'personaasignada=' + personaasignada + '&autorizado=' + autorizado + '&entregado=' + entregado;	

		
		$.ajax({
				type: "POST",
				url: "php/reporteria_asignacion.php",
				data:  {'valores': valores , 
				'dataString': dataString }, 
				success: function(data) {
					
					window.location.href = 'php/reporteria_asignacion.php';
				}
			});







<!DOCTYPE html>
<html>
<body>
data-toggle="modal" data-target=".bs-example-modal-lg"
<button class="dt-button buttons-excel buttons-html5" tabindex="0" aria-controls="datatable" type="button"><span>Excel</span></button>
"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
initComplete: function () {
$('.buttons-excel').html('<span class="glyphicon glyphicon-file" data-toggle="tooltip" title="Export To Excel"/>')
}
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>

  
  https://code.jquery.com/jquery-3.5.1.js
    https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js
    https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js
    https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js
    https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js
    https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js
    https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js

    .dataTables_wrapper .dt-buttons {
  float:right;
}

echo'<script type="text/javascript">
window.location.href="../form.php";
    alert("Datos Ingresados");
    </script>';

<h2>HTML Forms</h2>

<form action="sdds.php">
 <select name="miselector" id="miselector" onchange="this.form.submit()">
 <option value="">Seleccionar</option>
 <option value="coches">Coches</option>
 <option value="casas">Casas</option>
</form>

///Lectura de la variable "en la misma página" desde php

<?php
echo "Select: ".$_GET["miselector"];
?>
</body>
</html>



<?php
      $sql = "SELECT * FROM Vequiposdesktop";
      $stmt = sqlsrv_query( $conn, $sql );
      if( $stmt === false) {
          die( print_r( sqlsrv_errors(), true) );
      }
      
      while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) { ?>
   <tbody>
                        <tr>
                          <td>#</td>
                          <td>
                          <ul class="list-inline">
                              <li>
                              <?php echo $row['nombreequipo'];?>
                              </li>
                            </ul>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                              <?php echo $row['marcca_desktop'];?>
                              </li>
                            </ul>
                          </td>
                          <td >
                          <ul class="list-inline">
                              <li>
                              <?php echo $row['modelo_desktop'];?>
                              </li>
                            </ul>
                          </td>
                          <td>
                         
                          </td>
                          <td>
                            <a  href="#"  class="btn btn-success btn-xs"> <span  class="glyphicon glyphicon-plus" aria-hidden="true"></span>Asignar </a>
                          
                          </td>
                        </tr>
                       <?php 
                       }
                       ?>
                        
                     
                
                      </tbody>
                    </table>  

                    <table class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 1%">#</th>
                          <th style="width: 20%">Project Name</th>
                          <th>Team Members</th>
                          <th>Project Progress</th>
                          <th>Status</th>
                          <th style="width: 20%">#Edit</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="57"></div>
                            </div>
                            <small>57% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="47"></div>
                            </div>
                            <small>47% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="77"></div>
                            </div>
                            <small>77% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="60"></div>
                            </div>
                            <small>60% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="12"></div>
                            </div>
                            <small>12% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="35"></div>
                            </div>
                            <small>35% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="87"></div>
                            </div>
                            <small>87% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="77"></div>
                            </div>
                            <small>77% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>Pesamakini Backend UI</a>
                            <br />
                            <small>Created 01.01.2015</small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="77"></div>
                            </div>
                            <small>77% Complete</small>
                          </td>
                          <td>
                            <button type="button" class="btn btn-success btn-xs">Success</button>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                            <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                            <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                          </td>
                        </tr>
                      </tbody>
                    </table>






































                    <form id="frmselect" action="#" method="POST" class="form-horizontal form-label-left">
						
						
								<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Centro de Distribucion</label>
									<div class="col-md-4 col-sm-4 ">
										<select  class="form-control"  name="ciudad" id="ciudad" >
											<option value="nulo" >Seleccione un Centro de Distribucion</option>
												<option value="SPS" >SPS</option>
												<option value="TGU">TGU</option>
												<option value="CELULAR">Proyesa</option>
												<option value="NUEVOS HORIZONTES">Nuevos Horizontes</option>
												<option value="GRALZA">Gralza</option>
											
										</select>
										
										
									</div>
								</div>


						
								<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Tipo-Equipo</label>
									<div class="col-md-4 col-sm-4 ">
										<select  class="form-control" name="tipoequipo" id="tipoequipo"  onclick="SelectRegistro();" >
											<option value="nada">Seleccione un Equipo</option>
											<option value="desktop" >Desktop</option>
											<option value="laptop">Laptop</option>
											<option value="celular">Celular</option>
											<option value="telefono">Telefono</option>
											<option value="otros">Otros</option>
										
										</select>
									
									</div>
								</div>
							
						</form>

						
								<!--FORMULARIO PARA LAPTOP-->
								<form  method="POST" action="php\insertardatos.php"  class="form-horizontal form-label-left">
								<div id="frmlaptop">
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Marca</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="lmarca" name="lmarca"  type="text"  class="form-control" placeholder="Marca">
										</div>
									</div>

									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="lmodelo" name="lmodelo" type="text" class="form-control" placeholder="Modelo">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Service Tag</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="lservicetag" name="lservicetag" type="text" class="form-control" placeholder="Service Tag">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Procesador</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="lprocesador" name="lprocesador" type="text" class="form-control" placeholder="Procesador">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">RAM</label>
										<div class="col-md-5 col-sm-5 ">
											<input  id="lram" name="lram" type="number" class="form-control" placeholder="Ram">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Disco Duro</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="ldiscoduro" name="ldiscoduro" type="number" class="form-control" placeholder="Disco Duro">
										</div>
									</div>
									<div class="form-group row">
										<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
										</label>
										<div class="col-md-9 col-sm-9 ">
											<textarea id="ldescripcion" name="ldescripcion" class="form-control" rows="3" placeholder="Descripcion"></textarea>
										</div>
									</div>
									<div class="ln_solid"></div>
									<div  id="btnlaptop"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button type="submit" class="btn btn-success">Submit</button>
											</div>
										</div>
									
							</div>
							
							</form>
							<!--FORMULARIO PARA LAPTOP-->

					<!--FORMULARIO PARA DESKTOP action="php\insertardatos.php"-->
					
			<div id="frmdesktop">
				<form  method="POST"   class="form-horizontal form-label-left">
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Marca</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dmarca" name="dmarca"  type="text"  class="form-control" placeholder="Marca" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dmodelo" name="dmodelo" type="text" class="form-control" placeholder="Modelo" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Service Tag</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dservicetag" name="dservicetag" type="text" class="form-control" placeholder="Service Tag" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Procesador</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="dprocesador" name="dprocesador" type="text" class="form-control" placeholder="Procesador" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">RAM</label>
						<div class="col-md-5 col-sm-5 ">
							<input  id="dram" name="dram" type="number" class="form-control" placeholder="Ram" required="required">
						</div>
					</div>
					<div class="form-group row ">
						<label class="control-label col-md-3 col-sm-3 ">Disco Duro</label>
						<div class="col-md-5 col-sm-5 ">
							<input id="ddiscoduro" name="ddiscoduro" type="number" class="form-control" placeholder="Disco Duro"required="required">
						</div>
					</div>
					<div class="form-group row">
						<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
						</label>
						<div class="col-md-9 col-sm-9 ">
							<textarea id="ddescripcion" name="ddescripcion"  class="form-control" rows="3" placeholder="Descripcion"></textarea>
						</div>
					</div>
					<div class="ln_solid"></div>
					<div  id="btndesktop"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button  id="btnEnviar"  class="btn btn-success" >Submit</button>
											</div>
										</div>
			</div>		
			
			</form>
								<!--FORMULARIO PARA DESKTOP-->		


									

							<!--FORMULARIO PARA CELULAR-->
							
							<div id="fmrcelular">
							<form  method="POST" action="php\insertardatos.php"  class="form-horizontal form-label-left">
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Marca</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cmarca" type="text" class="form-control" placeholder="Marca">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cmodelo" type="text" class="form-control" placeholder="Modelo">
										</div>
									</div>
									<div class="form-group row ">
										<label class="control-label col-md-3 col-sm-3 ">IMEI</label>
										<div class="col-md-5 col-sm-5 ">
											<input id="cimei" name="cimei" type="number" class="form-control" placeholder="Imei">
										</div>
									</div>
								
									<div class="form-group row">
										<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
										</label>
										<div class="col-md-9 col-sm-9 ">
											<textarea id="cdescripcion" class="form-control" rows="3" placeholder="Descripcion"></textarea>
										</div>
									</div>
									<div class="ln_solid"></div>
									<div  id="btncelular"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button type="submit" class="btn btn-success">Submit</button>
											</div>
										</div>
							</div>
							
							</form>
							<!--FORMULARIO PARA CELULAR-->

							<!--FORMULARIO PARA TELEFONO-->
						
							<div id="frmtel">
								<form  method="POST" action="php\insertardatos.php"  class="form-horizontal form-label-left">
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Marca</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="tmarca" type="text" class="form-control" placeholder="Marca">
									</div>
								</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="tmodelo" type="text" class="form-control" placeholder="Modelo">
									</div>
								</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">IMEI</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="timei" type="number" class="form-control" placeholder="Imei">
									</div>
								</div>
							
								<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
									</label>
									<div class="col-md-9 col-sm-9 ">
										<textarea id="tdescripcion" class="form-control" rows="3" placeholder="Descripcion"></textarea>
									</div>
								</div>
								<div class="ln_solid"></div>
								<div  id="btntel"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button type="submit" class="btn btn-success">Submit</button>
											</div>
										</div>
							</div>
							</form>
						
							<!--FORMULARIO PARA TELEFONO-->

							<!--FORMULARIO PARA OTROS-->
							
							<div id="frmotros" action="#" class="frmotros">
							<form  method="POST"   class="form-horizontal form-label-left">
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Nombre del Equipo</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="onombreequipo" type="text" class="form-control" placeholder="Nombre del Equipo">
									</div>
								</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Marca</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="omarca" type="text" class="form-control" placeholder="Marca">
									</div>
								</div>
								<div class="form-group row ">
									<label class="control-label col-md-3 col-sm-3 ">Modelo</label>
									<div class="col-md-5 col-sm-5 ">
										<input id="omodelo" type="text" class="form-control" placeholder="Modelo">
									</div>
								</div>
								
								<div class="form-group row">
									<label class="control-label col-md-3 col-sm-3 ">Descripcion <span class="required">*</span>
									</label>
									<div class="col-md-9 col-sm-9 ">
										<textarea id="odescripcion"  class="form-control" rows="3" placeholder="Descripcion"></textarea>
									</div>
								</div>
								
							<div  id="btnotros"  class="item form-group">
											<div  class="col-md-6 col-sm-6 offset-md-3">
												
												<button class="btn btn-primary" type="reset">Reset</button>
												<button   class="btn btn-success" >Submit</button>
											</div>
										</div>
										
								
							</div>
							
								</form>
						
							<!--FORMULARIO PARA OTROS-->
							
					


			

			
		
			<!-- /page content -->
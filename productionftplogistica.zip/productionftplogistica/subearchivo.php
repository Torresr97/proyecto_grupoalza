<?php
	//formulario de upload por jorge luis martinez
	//http://miscodigos.jlmnetwork.com/
	$extension = explode(".",$archivo_name);
	$num = count($extension)-1;
	if($extension[$num] == "zip")
		{
		if($archivo_size < 30000)
		{
		if(!copy($archivo, "archivos/".$archivo_name)
		{
		echo "error al copiar el archivo";
		}
		else
		{
		echo "archivo subido con exito";
		}
		}
		else
		{
		echo "el archivo supera los 30kb";
		}
		}
		else
		{
		echo "el formato de archivo no es valido, solo .zip";
		}
?>

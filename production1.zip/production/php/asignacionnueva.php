<?php 
include("conexion1.php");
include('reporteria_asignacion.php');

var_dump($_POST);
$idequipo=$_POST['midequipo'];
$equipo=$_POST['mequipo'];
$marca=$_POST['mmarca'];
$modelo=$_POST['mmodelo'];
$procesador=$_POST['mprocesador'];
$servicetag=$_POST['mservicetag'];
$ram=$_POST['mram'];
$discoduro=$_POST['mdiscoduro'];
$descripcion=$_POST['mdescripcion'];
$empleado=$_POST['mempleado'];
$area=$_POST['area'];
$autorizado=$_POST['autorizado'];
$entregado=$_POST['entregado'];
      

      







        

    
                            // specify params - MUST be a variable that can be passed by reference!
                    $myparams['idempleado'] =  $empleado;
                    $myparams['idequipo'] =  $idequipo;
                    $myparams['asignador'] = $entregado;
                    $myparams['autorizador'] = $autorizado;
                   


                   // $myparams['marca_laptop'] = null;

                    // Set up the proc params array - be sure to pass the param by reference
                    $procedure_params = array(
                    array(&$myparams['idempleado'], SQLSRV_PARAM_IN),
                    array(&$myparams['idequipo'], SQLSRV_PARAM_IN),
                    array(&$myparams['asignador'], SQLSRV_PARAM_IN),
                    array(&$myparams['autorizador'], SQLSRV_PARAM_IN)
                   
                    );

                    // EXEC the procedure, {call stp_Create_Item (@Item_ID = ?, @Item_Name = ?)} seems to fail with various errors in my experiments
                    $sql = "EXEC Proc_nuevaasignacion @idempleado = ?, @idequipo = ?,@asignador = ?,@autorizador = ?";

                    $stmt = sqlsrv_prepare($conn, $sql, $procedure_params);

                    if( !$stmt ) {
                    die( print_r( sqlsrv_errors(), true));
                    }

                    if(sqlsrv_execute($stmt)){
                    while($res = sqlsrv_next_result($stmt)){
                        // make sure all result sets are stepped through, since the output params may not be set until this happens
                    }
                    // Output params are now set,
                  
                   
                    echo'<script type="text/javascript">
                    window.location.href="../form.php";
                            alert("Datos Ingresados");
                            </script>';


                           
                    }else{
                    die( print_r( sqlsrv_errors(), true));
                    }      
                            










?>
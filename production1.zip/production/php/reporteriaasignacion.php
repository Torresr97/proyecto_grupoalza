<?php

require('../fpdf/fpdf.php');
include('variables.php');

$idequipo;
$equipo;
$marca;
$modelo;
$procesador;
$servicetag;
$ram;
$discoduro;
$descripcion;
$empleado;
$area;
$autorizado;
$entregado;


 date_default_timezone_set('America/Tegucigalpa');
// En windows
setlocale(LC_TIME, 'spanish');
$hoy = strftime('%A %e de %B de %C%g');
class PDF extends FPDF
{
    // Cabecera de página
    function Header()
    {
        // Logo (posicion y, posicion x, ancho img, alto img )
    // $this->Image('../images/logogrupoalza.png',2,2,200,50);
    
    $this->Image('../images/logoalza.png',2,2,200,50);
        // Arial bold 15
        $this->SetFont('Arial','B',15);
        // Movernos a la derecha
        //$this->Cell(80);
        // Título
        //$this->Cell(80,80,'Asignacion de Equipo',1,0,'C');
        // Salto de línea
        $this->Ln(20);
    }

    // Pie de página
    function Footer()
    {
        // Posición: a 1,5 cm del final
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial','I',8);
        // Número de página
        $this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }
    function cabeceraVertical($cabecera)
    {
        $this->SetXY(10, 150); //Seleccionamos posición
        $this->SetFont('Arial','B',12); //Fuente, Negrita, tamaño
 
        foreach($cabecera as $columna)
        {
            //Parámetro con valor 2, cabecera vertical
            $this->Cell(40,10, utf8_decode($columna),1, 2 , 'L' );
        }
    }
    function Datos($datos)
    {
        $this->SetXY(50, 150); //Seleccionamos posición
        $this->SetFont('Arial','',12); //Fuente, Negrita, tamaño
 
        foreach($datos as $columna)
        {
            //Parámetro con valor 2, cabecera vertical
            $this->Cell(60,10, utf8_decode($columna),1, 2 , 'L' );
        }
    }
}




$pdf = new PDF();
$pdf-> AliasNbpages();
$pdf->AddPage();
$pdf->Ln(30);
$pdf->Cell(20);
$pdf->SetFont('Arial','B',24);
$pdf->Cell(40,5,'Asignacion de Equipo de Computo');
$pdf->SetFont('Arial','',14);
$pdf->Ln(20);
$pdf->Cell(-5);
$pdf->Cell(40,5,$hoy);
$pdf->Ln(15);
$pdf->Cell(-5);
$pdf->Cell(40,7,'Por medio del presente se hace entrega del Equipo-'.$equipo.' a:'.$empleado.'  quien ');
$pdf->Ln(6);
$pdf->Cell(-5);
$pdf->Cell(40,7,'se desempena en el area de:'.$area.'. Se compromete a cumplir con la politicas establecidas');
$pdf->Ln(6);
$pdf->Cell(-5);
$pdf->Cell(40,7,'por el departamento de IT revisadas por Gerencia.');
$pdf->Ln(15);
$pdf->Cell(-5);
$pdf->Cell(40,7,'Este mismo se comprometea cuidar la Integridad Fisica del Equipo.');
$pdf->Ln(15);
$pdf->Cell(-5);
$pdf->Cell(40,7,'El Equipo cuenta con las Siguientes especificaciones:');
$pdf->Ln(15);

$miCabecera = array('Equipo', 'Marca', 'Modelo', 'ServiceTag', 'Procesador', 'Ram', 'DiscoDuro','Nota');
$datos = array($equipo, $marca, $modelo,$servicetag ,$procesador,$ram,$discoduro,$descripcion);
// Tabla simple

$pdf->cabeceraVertical($miCabecera);
$pdf->Datos($datos);
$pdf->Ln(30);
$pdf->Cell(5);
$pdf->Cell(40,6,'___________________________                                         ___________________________');
$pdf->Ln(5);
$pdf->Cell(5);
$pdf->Cell(40,6,'Autorizado Por: '.$autorizado.'                                        Entregado Por: '.$entregado);


$pdf->output();


?>
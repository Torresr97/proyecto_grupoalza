<?php
var_dump($_POST);
$idequipo=$_POST['midequipo'];
$equipo=$_POST['mequipo'];
$marca=$_POST['mmarca'];
$modelo=$_POST['mmodelo'];
$procesador=$_POST['mprocesador'];
$servicetag=$_POST['mservicetag'];
$ram=$_POST['mram'];
$discoduro=$_POST['mdiscoduro'];
$descripcion=$_POST['mdescripcion'];
$empleado=$_POST['mempleado'];
$area=$_POST['area'];
$autorizado=$_POST['autorizado'];
$entregado=$_POST['entregado'];
      

?>